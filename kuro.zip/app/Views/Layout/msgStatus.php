<?php if (session()->getFlashdata('msgDanger')) : ?>
    <div class="alert alert-danger d-flex align-items-center" role="alert">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="margin-right: 12px;">
            <path d="M13,14H11V10H13M13,18H11V16H13M1,21H23L12,2L1,21Z"/>
        </svg>
        <div><?= session()->getFlashdata('msgDanger') ?></div>
    </div>
<?php elseif (session()->getFlashdata('msgSuccess')) : ?>
    <div class="alert alert-success d-flex align-items-center" role="alert">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="margin-right: 12px;">
            <path d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/>
        </svg>
        <div><?= session()->getFlashdata('msgSuccess') ?></div>
    </div>
<?php elseif (session()->getFlashdata('msgWarning')) : ?>
    <div class="alert alert-warning d-flex align-items-center" role="alert">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="margin-right: 12px;">
            <path d="M13,14H11V10H13M13,18H11V16H13M1,21H23L12,2L1,21Z"/>
        </svg>
        <div><?= session()->getFlashdata('msgWarning') ?></div>
    </div>
<?php else : ?>
    <?php if (session()->has('userid')) : ?>
        <?php if (isset($messages)) : ?>
            <div class="alert alert-<?= $messages[1] ?> d-flex align-items-center" role="alert">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="margin-right: 12px;">
                    <path d="M13,9H11V7H13M13,17H11V11H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"/>
                </svg>
                <div><?= $messages[0] ?></div>
            </div>
        <?php else : ?>
            <div class="alert alert-primary d-flex align-items-center" role="alert">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="margin-right: 12px;">
                    <path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,17C12.56,17 13,16.56 13,16V12C13,11.44 12.56,11 12,11C11.44,11 11,11.44 11,12V16C11,16.56 11.44,17 12,17M12,9A1,1 0 0,0 13,8A1,1 0 0,0 12,7A1,1 0 0,0 11,8A1,1 0 0,0 12,9Z"/>
                </svg>
                <div>
                    <strong>Welcome back, <?= getName($user) ?>!</strong>
                    <div style="font-size: 14px; opacity: 0.9;">You're successfully logged in to Prince Panel</div>
                </div>
            </div>
        <?php endif; ?>
    <?php else : ?>
        <div class="alert alert-primary alert-dismissible d-flex align-items-center" role="alert">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="margin-right: 12px;">
                <path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,17C12.56,17 13,16.56 13,16V12C13,11.44 12.56,11 12,11C11.44,11 11,11.44 11,12V16C11,16.56 11.44,17 12,17M12,9A1,1 0 0,0 13,8A1,1 0 0,0 12,7A1,1 0 0,0 11,8A1,1 0 0,0 12,9Z"/>
            </svg>
            <div>
                <strong>Welcome to Prince Panel!</strong>
                <div style="font-size: 14px; opacity: 0.9;">Please login to access your dashboard</div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
<?php endif; ?>